Included here are the SAO files containing the URSI characteristics and electron density profiles derived from ionograms as used in the paper Verhulst et al. (2022) "Multi-instrument detection in Europe of ionospheric disturbances caused by the 15 January 2022 eruption of the Hunga volcano" J. Space Weather Space Climate, doi:10.1051/swsc/2022032. 

Data from 12 European ionosonde observatories are included, all operating some version of the Lowell digital ionosonde. All data have been manually verified by human experts.

The description of the SAO file format can be found on-line at the URL: http://ulcar.uml.edu/~iag/SAO-4.3.htm

These files can be conveniently read by using the SAO Explorer, which can be freely downloaded from the webpage https://ulcar.uml.edu/SAO-X/SAO-X.html.
